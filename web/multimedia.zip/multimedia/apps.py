from django.apps import AppConfig

class MultimediaConfig(AppConfig):
    name = 'multimedia'
